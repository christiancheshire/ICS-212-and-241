/*
 * Structures2.c
 *
 *  Created on: Sep 10, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use structures in a C program - Assignment 5
 *     Version: 10/17/17
 *        Note: Revised version with errors resolved
 */

#include <stdio.h>
#include <string.h>

/*
 * Variables to keep track of checkbook items, temp is used to clear the buffer
 */
int checkInc = 1;
int bookCount = 1;
char temp[50];

/*
 * Check Structure
 */
struct check {
	int num;
	char date[10];
	char to[30];
	float amount;
	char descrip[30];
};

/*
 * The User's Checkbook
 */
struct check checkbook[11];


/* FUNCTIONS */

/*
 * Add Function
 * returns newCheck
 */
struct check add() {

	/* The check */
	struct check newCheck;

        printf("Type in the Check Number: ");
	scanf("%d", &newCheck.num);

        /* Removes leftover newline */
	fgets(temp, 50, stdin);

	printf("Enter date in format dd/mm/yy: ");
	fgets(newCheck.date, 8, stdin);

	/* Removes leftover newline */
	fgets(temp, 50, stdin);
	
	printf("Enter recipient: ");
	fgets(newCheck.to, 30, stdin);
	
        printf("Enter check amount in decimal form: ");
	scanf("%f", &newCheck.amount);

	/* Removes leftover newline */
	fgets(temp, 50, stdin);

	printf("Enter description: ");
	fgets(newCheck.descrip, 30, stdin);

	/* Print check info */
	printf("--------------------\n");
	printf("Check Number: %d\n", newCheck.num);
	printf("Date: %s\n", newCheck.date);
	printf("To: %s\n", newCheck.to);
	printf("Amount: %.2f\n", newCheck.amount);
	printf("Description: %s", newCheck.descrip);
	printf("--------------------\n");

	/* Increment checkInc to keep track of checks */
	checkInc++;

	return newCheck;
}

/*
 * Display Check Function
 * @param the check to diplay
 */
void displayCheck(struct check thisCheck) {

	printf("--------------------\n");
	printf("Check #: %d\n", thisCheck.num);
	printf("Date: %s\n", thisCheck.date);
	printf("To: %s\n", thisCheck.to);
	printf("Amount: %.2f\n", thisCheck.amount);
	printf("Description: %s\n", thisCheck.descrip);
	printf("--------------------\n");

}

/*
 * Display Checkbook Function
 */
void displayCheckbook() {
	printf("Your checkbook: \n");
	for (int i = 0; i < checkInc; i++) {
		displayCheck(checkbook[i]);
	}
}

/*
 * Main Function
 */
int main() {

	/* Keeps user's choice */
	char choice = ' ';
		
	/* Prints greeting */
  	printf("Aloha! Welcome to your checkbook. Please select an option: \n");
	
	/* Runs while user does not want to exit the program */
	while ( choice != 'e') {
	
		/* Instructions to user */
		printf("Press 'a' to add a check \n"); 
		printf("Press 'v' to view checkbook \n");
		printf("Press 'c' to view a specific check \n"); 
		printf("Press 'e' to exit \n\n");
		printf("Enter your choice: \n");

		/* Get user choice */
		scanf("%c", &choice);

		if (choice == 'a' ) {
			checkbook[bookCount] = add();
			bookCount++;
		}

		else if (choice == 'v') {     
			displayCheckbook();    
			/* Removes leftover newline */
			fgets(temp, 50, stdin);
		}

		else if (choice == 'c') {
			int i;
			printf("Enter the check number: \n");
			scanf(" %d", &i); 
			displayCheck(checkbook[i]);
			/* Removes leftover newline */
			fgets(temp, 50, stdin);
		}

		else if (choice == 'e') {
			printf("Thank you for using your checkbook. Good bye!");
			break;
		}

		else {
			printf("You must enter a valid option.");   
		}
	}

	return(0);

}