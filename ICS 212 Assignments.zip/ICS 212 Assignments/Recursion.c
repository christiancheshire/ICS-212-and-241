/*
 * Recursion.c
 *
 *  Created on: Oct 7, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use recursion in a C program - Assignment 7
 */

#include<stdio.h>

/* Function Declarations */
int sum(int number);
int power(int base, int exponent);

/* Main function */
int main() {

  /* Variables for user input, number and exponent */
  int userInput, num, numPwr;

  /* While loop for different user options */
  while (1) {

	/* Instructions to user */
    	printf("Enter 1 to add digits of an integer together. Enter 2 for the power function. Press 3 to exit the program.");
    	
	/* Gather user input */
	scanf("%d", &userInput);

	/* If input is number 1, then carry out the sum function and print the result */
    	if (userInput == 1) {
    		printf("Enter the number:");
    		scanf("%d", &num);
    		printf("The output of the sum function is %d \n", sum(num));

	/* If input is number 2, then carry out the power function and print the result */
    	} else if (userInput == 2) {
    		printf("Enter the base:");
    		scanf("%d", &num);
    		printf("Enter the exponent:");
    		scanf("%d", &numPwr);
    		printf("The output of the power function is %d \n", power(num, numPwr));
    	
	/* If user input is 3, then exit the program */
	} else if (userInput == 3) {
      		break;

	/* Otherwise, prompt the user to input a valid option */
    	} else {
		printf("Please select a valid option. \n");
	}

   }

}

/*
 * Sum function
 * Adds the digits of an integer together
 * @param the number
 */
int sum(int number) {
  	
	if(number != 0) {
    		return (number % 10 + sum(number / 10));
  	} else {
    		return 0;
  	}
 
}

/*
 * Power function
 * Calculates the power of a given number and exponent
 * @param base the base number
 * @param exponent the power which the base will be raised to
 */
int power(int base, int exponent) {

  	if(exponent == 0) {
    		return 1;
  	} else {
    		return base * power(base, exponent-1);
  	}

}

