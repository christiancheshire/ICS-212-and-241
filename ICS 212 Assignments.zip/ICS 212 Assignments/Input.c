/*
 * Input.c
 *
 *      Author: Christian Cheshire
 *     Purpose: Accept input and manipulate character strings - Assignment 3
 *  Created on: Aug 30, 2017
 *
 */

#include <stdio.h>
#include <string.h>
 
int main(){

    /* Arrays to store user's name and home state */
    
    char name[30];
    char initials[4];
    char state[30];

    /* Gather information regarding user's name and initials */
    
    printf("Enter your name: \n");
    fgets(name,30,stdin);

    /* Get user's initials */

    int d;
    for(d=0;d<30-1;d++) {
    if(name[d] == ' ')
        initials[1]=name[d+1];
    }

    initials[0] = name[0];
    initials[2] = ',';
    initials[3] = ' ';
    
    /* Greet user using their name and initials */

    printf("\nAloha, %s\n", name);
    printf("Your initials are %s\n", initials);

    /* Gather information regarding user's home state */

    printf("\nEnter your home state: \n");
    fgets(state,30,stdin);

    /* Print user's home state */

    printf("\nYour home state is %s", state);
    
    return(0);

}