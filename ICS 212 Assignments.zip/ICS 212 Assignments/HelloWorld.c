/*
 * Helloworld.c
 *
 *  Author: Christian Cheshire
 *  Purpose: Create, compile, and execute a C program and display output - Assignment 2
 *  Created on: Aug 21, 2017
 *
 */

#include <stdio.h>

int main(void){

	printf("Aloha!\n");

	printf("My name is Christian Cheshire\n");

	printf("My home campus is University of Hawaii - Manoa\n");

	printf("I am majoring in Computer Science.");

	return 0;
}