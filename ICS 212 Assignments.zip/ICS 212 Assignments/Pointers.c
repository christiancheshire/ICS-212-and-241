/*
 * Pointers.c
 *
 *  Created on: Sep 24, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use and manipulate variables using pointers - Assignment 6
 */

#include<stdio.h>

int main() {

  /* Int variables set to different values */  
  int value1 = 1;
  int value2 = 2; 

  /* Pointers */
  int *pointer1;
  int *pointer2;
  int *pointer3;

  /* Point first two pointers to the first value */
  pointer1 = &value1; 
  pointer2 = &value1;

  /* Points third pointer to the second value */
  pointer3 = &value2;

  /* Print variable addresses and their values */
  printf("-----------------\nVariable addresses and values:\n");

  printf("\nAddress of the first variable value = %x \nAddress of the second variable value= %x",&value1,&value2);
  printf("\n\nValue of the first variable = %d \nValue of the second variable = %d",value1,value2); 

  /* Print contents of the pointers */
  printf("\n-----------------\nContents of the pointers:\n");

  printf("\nPointer1 points to %x whose value is %d",pointer1,*pointer1);
  printf("\nPointer2 points to %x whose value is %d",pointer2,*pointer2);
  printf("\nPointer3 points to %x whose value is %d",pointer3,*pointer3);

  /* Changes the first variable value */
  value1 = 10;

  printf("\n\nFirst variable value is changed. Value1 = %d",value1);
 
  /* Print pointer memory locations */ 
  printf("\n-----------------\nPointer memory locations:\n");

  if(pointer1 == &value1) {
	printf("\nPointer1 points to the first variable value. Value1 = %d. The memory location of the first pointer is %x", *pointer1, pointer1);
  }

  if(pointer2 == &value1) {
	printf("\nPointer2 points to the first variable value. Value1 = %d. The memory location of the second pointer is %x", *pointer2, pointer2);
  }

  if(pointer3 == &value1) {
	printf("\nPointer3 points to the first variable value. Value1 = %d. The memory location of the third pointer is %x", *pointer3, pointer3);
  }


  /* Set value at pointer3's memory location */
  *pointer3 = 20;

  printf("\n\nThe memory location of the third pointer (pointer3) is %x", pointer3);
  printf("\nThe second variable value is %d", value2);

  return 0;

}