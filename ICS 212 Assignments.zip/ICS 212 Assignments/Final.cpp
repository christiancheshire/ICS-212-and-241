/*
 * Final.cpp
 *
 *  Created on: Oct 29, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use inheritance and polymorphism in a C++ program - Assignment 13
 */

#include <iostream>
#include <string>

using namespace std;

/* PERSON CLASS */
class Person {
	
    protected: 
	string name;  // Person's name
	string campus;  // Person's campus

    // Public functions
    public:		
	void set_name(string thisName);  // Sets the name of the person
	void set_campus(string thisCampus);  // Sets the campus of the person
	void display_info();  // Displays the information for the person
	
};

// PERSON function implementations
void Person::set_name(string thisName) {
	name = thisName;
}

void Person::set_campus(string thisCampus) {
	campus = thisCampus;
}	

void Person::display_info() {
	cout << "Person: " << name << ", " << campus << "\n";
}

/* STUDENT CLASS */
class Student : public Person {

    private:
	int studentID;  // Student ID number
	string major;  // Student major

    public:
	void set_ID(int theID);  // Sets student ID
	void set_major(string theMajor);  // Sets student major
	void display_student();  // Displays student information
};

// STUDENT function implementations
void Student::set_ID(int theID) {
	studentID = theID;
}

void Student::set_major(string theMajor) {
	major = theMajor;
}

void Student::display_student() {
	cout << "Student Information: " << name << ", " << campus << ", " << studentID << ", " << major << "\n";
}

// STAFF CLASS
class Staff : public Person {

    private:
	string staffID;  // Staff ID number
	string department;  // Staff department

    public:
	void set_staffID(string theID);  // Sets staff ID 
	void set_department(string theDep);  // Sets staff department
	void display_staff();  // Displays staff member information
};

// STAFF function implementations
void Staff::set_staffID(string theID) {
	staffID = theID;
}

void Staff::set_department(string theDep) {
	department = theDep;
}

void Staff::display_staff() {
	cout << "Staff Information: " << name << ", " << campus << ", " << staffID << ", " << department << "\n";
}

// MAIN
int main() {

	Student theStudent;  // Student
	Staff theStaff;  // Staff member

	// User input variables
	string stuName; 
	string stuCampus;
	int stuID;
	string stuMajor;

	string staffName;
	string staffCampus;
	string staffID;
	string staffDept;

	// Get student info from user 
	cout << "\nEnter the information for the student \n";

	cout << "Name: ";
	getline(cin, stuName);
	
	cout << "Campus: ";
	getline(cin, stuCampus);

	cout << "Major: ";
	getline(cin, stuMajor);

	cout << "ID: ";
	cin >> stuID;
	cin.get();

	// Pass student info to object, then display info
	theStudent.set_name(stuName);
	theStudent.set_campus(stuCampus);
	theStudent.set_ID(stuID);
	theStudent.set_major(stuMajor);

	theStudent.display_student();

	// Get staff member info from user
	cout << "\nEnter the information for the staff member \n";

	cout << "Name: ";
	getline(cin, staffName);
	
	cout << "Campus: ";
	getline(cin, staffCampus);

	cout << "Department: ";
	getline(cin, staffDept);

	cout << "ID: ";
	getline(cin, staffID);

	// Pass staff member info to object,  the display info
	theStaff.set_name(staffName);
	theStaff.set_campus(staffCampus);
	theStaff.set_staffID(staffID);
	theStaff.set_department(staffDept);

	theStaff.display_staff();

	return 0;
}