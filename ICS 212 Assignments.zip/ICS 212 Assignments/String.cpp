/*
 * String.cpp
 *
 *  Created on: Oct 21, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use and manipulate C++ strings - Assignment 10
 */

#include <iostream>
#include <string>

using namespace std;

int main() {
	
	// Strings for user's name and home state
	string name;
	string state;

	// Collect user's name
	cout << "Enter your name: ";
	getline(cin, name);

	// Collect user's home state
	cout << "Enter your home state: ";
	getline(cin, state);   		

	// Print greeting with user's name, initials, and home state
	cout << "\nAloha, " << name << ".\n";
	cout << "Your initials are " << name[0] << name[name.find(" ") + 1] <<".\n";
	cout << "Your home state is " << state << ".\n";
	
	return 0;
}