/*
 * FunctionsA4.c
 *
 *  Created on: Sep 5, 2017
 *     Purpose: Define, code, and use functions in C - Assignment 4
 *      Author: Christian Cheshire
 */

#include <stdio.h>

   int factorial(int i); //factorial int
   int power(int base, int exp); //power int with base and exponent


   int main() {

        /* Gather input from user */

   	int input[3]; //Stores user input

        printf("Enter the number you want to find the factorial of: \n");

     	scanf("%d", &input[0]);

   	printf("Enter the base number for a power function: \n");

        scanf("%d", &input[1]);

   	printf("Enter the exponent for the base number: \n");

   	scanf("%d", &input[2]);

   	printf("The factorial of %d is %d\n", input[0], factorial(input[0]));

   	printf("The power of %d raised to the %d is %d\n", input[1], input[2], power(input[1], input[2]));


   }



  /*
   * Factorial Function
   * Returns the factorial of a given integer
   */


   int factorial(int i) {

   	int n = 1;
    	int factorial;

        /* If number is positive */

    	if (i > 0) {
	    	while(i > 0) {
		   	n = n * i;
 		   	i--;
	    	}

	    return n;
    	}

        
        /* If number is negative */

    	if (i < 0 && i % 2) {
        	while(i < 0) {
            		n = n * i;
            		i++;
        	}
                
                return n;
                
       	} else if (i < 0) {
		while(i < 0) {
			n = n * i;
			i++;
		}

		return n * -1;

	}

   }


  /*
   * Exponent Function
   * Returns the power of the given base and exponent
   */

   int power(int base, int exp) {
   
	int result = 1;
	while (exp) {
		result = result * base;
                exp--;
        }
        return result;

   }
