/*
 * Encapsulation.cpp
 *
 *  Created on: Oct 29, 2017
 *      Author: Christian Cheshire
 *     Purpose: Use encapsulation in a C++ class - Assignment 12
 */

#include <iostream>
#include <string>

using namespace std;

// Person class
class Person {
	
    private: 
	string name;  // Person's name
	string campus;  // Person's campus

    // Public functions
    public:		
	void set_name(string thisName);  // Sets the name of the person
	void set_campus(string thisCampus);  // Sets the campus of the person
	void display_info();  // Display's the information for the person
	
};

//Function implementations
void Person::set_name(string thisName) {
	name = thisName;
}

void Person::set_campus(string thisCampus) {
	campus = thisCampus;
}	

void Person::display_info() {
	cout << "Person: " << name << ", " << campus << "\n";
}

// Main 
int main() {

	Person personList[5];  // Array of persons

	// First person
	personList[0].set_name("Peter Smith"); 
	personList[0].set_campus("UH Manoa");
	
	// Second person
	personList[1].set_name("John Brown");
	personList[1].set_campus("UH Hilo");

	// Third person
	personList[2].set_name("Carl Carter");
	personList[2].set_campus("Leeward CC");

	for (int i = 0; i < 5; i++) {
		personList[i].display_info();  // Display the info for each person
	}

	return 0;
}