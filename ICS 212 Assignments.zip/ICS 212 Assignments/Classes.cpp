/*
 * Classes.cpp
 *
 *  Created on: Oct 21, 2017
 *      Author: Christian Cheshire
 *     Purpose: Create classes and use objects in C++ - Assignment 11
 */

#include <iostream>
#include <string>

using namespace std;

// Warranty class
class Warranty {
	
    private: 
	string make;
	string model;
	int modelYear;
	int length;
	int currentYear = 2017;

    // Public functions
    public:		
	void set_Make(string thisMake);  // Sets the make of the vehicle
	void set_Model(string thisModel);  // Sets the model of the vehicle
	void set_ModelYear(int thisModelYear);  // Sets the year of the vehicle
	void set_WarrantyLength(int thisWarrantyLength);  // Sets the warranty length

	string get_Make();  // Gets the vehicle make
	string get_Model();  // Gets the vehicle model
	int get_ModelYear();  // Gets the vehicle year
	int get_WarrantyLength();  // Gets the warranty length
	int get_CurrentYear();  // Gets the current year

	bool calculate_Warranty();  // Calculates whether or not the warranty is valid

};

//Function implementations
void Warranty::set_Make(string thisMake) {
	make = thisMake;
}

void Warranty::set_Model(string thisModel) {
	model = thisModel;
}

void Warranty::set_ModelYear(int thisModelYear) {
	modelYear = thisModelYear;
}

void Warranty::set_WarrantyLength(int thisWarrantyLength) {
	length = thisWarrantyLength;
}

string Warranty::get_Make() {
	return make;
}

string Warranty::get_Model() {
	return model;
}	

int Warranty::get_ModelYear() {
	return modelYear;
}

int Warranty::get_WarrantyLength() {
	return length;
}

int Warranty::get_CurrentYear() {
	return currentYear;
}

	
bool Warranty::calculate_Warranty() {
	int check = modelYear + length - currentYear;
	if (check < 0)
		return false;

	return true;
}

// Main 
int main() {

	char c = ' ';  // User option
	Warranty userVehicle;  // Object
	string userMake;  // User input
	string userModel;  // User input
	int userModelYear;  // User input
	int userWarrantyLength;  // User input

	cout << "Welcome to your vehicle warranty checker.";  // Greet user
	
	while (c != 'x') {  // While user option is not exit

	   cout << "\n\nEnter 'a' to check a warranty or 'x' to exit: \n";  // Instructions to user

	   cin.get(c);  // Get the user's input
	   cin.get();

	   if (c == 'x') {
		printf("Thank you for using your warranty checker. Good bye!");
		break;
	   
	   } else {

	       	// User input
		cout << "Enter your vehicle make: ";
		getline(cin, userMake);

		cout << "Enter your vehicle model: ";
		getline(cin, userModel);

		cout << "Enter your vehicle year: ";
		cin >> userModelYear;

		cout << "Enter your warranty length: ";
		cin >> userWarrantyLength;
	

		// Pass user input to the object
		userVehicle.set_Make(userMake);
		userVehicle.set_Model(userModel);
		userVehicle.set_ModelYear(userModelYear);
		userVehicle.set_WarrantyLength(userWarrantyLength);

		userVehicle.calculate_Warranty(); 

		// Print the information
		cout << "\nVehicle make: " << userVehicle.get_Make();	
		cout << "\n";
		cout << "Vehicle model: " << userVehicle.get_Model();
		cout << "\n";
		cout << "Vehicle year: " << userVehicle.get_ModelYear();	
		cout << "\n";
		cout << "Warranty length: " << userVehicle.get_WarrantyLength();	
		cout << "\n";
		cout << "Current year: " << userVehicle.get_CurrentYear();	
		cout << "\n";

		// Print if warranty is valid or not
		if (userVehicle.calculate_Warranty() == 0) {
			cout << "Your warranty is invalid";
		} else {
			cout << "Your warranty is valid";
        	}
	   }

	   cin.get(); // Clear buffer
	}

	return 0;
}